import './App.css';
import Counter from './components/Counter';
import Card from './components/card';
import {useState, useEffect} from 'react';


const App = () => {

const flashcards = [
    {question: "ستاسو نوم چی ده؟", answer: "What is your name?"},
    {question: "تاسو څنګه یئ؟", answer:"How are you?" },
    {answer:"Where are you from?", question: "تاسو د کوم ځای یاست؟"},
    {answer:"What is your job?", question: "ستاسو کار څه دی؟"},
    {answer:"I am happy to see you.", question: "زه ستا په لیدو خوشحاله شوم"},
    {answer:"I am from Afghanistan.", question: "زه د افغانستان یم"},
];

const [currentCard, setCurrentCard] = useState(0);
const [correct, setCorrect] = useState(0);
const [answer, setAnswer] = useState('');
const [streak, setStreak] = useState(0);
const [color, setColor] = useState(false);

useEffect(() => {
  const answerBox = document.querySelector('.answer');
  
  if (color === true) {
    answerBox.classList.add('correct');
    answerBox.classList.remove('incorrect');
  } else if (color === false) {
    answerBox.classList.add('incorrect');
    answerBox.classList.remove('correct');
  } else {
    // Reset to neutral (remove both classes)
    answerBox.classList.remove('correct', 'incorrect');
  }
}, [color]);



const checkAnswer = () => {
  if (answer === flashcards[currentCard].answer){
    setCorrect(correct + 1);
    setColor(true);
  
    
  }
  else{
    setStreak(() => correct > streak ? correct : streak);
    setCorrect(0);
    setColor(false);
  
  }

}


const nextCard = () => {
    setCurrentCard((curr) => (curr + 1) % flashcards.length);
    setAnswer(''); 
    setColor(null);
};

const prevCard = () => {
  setCurrentCard((curr) => curr=== 0 ?flashcards.length -1 : curr - 1);
  setAnswer(''); 
  setColor(null);
};




  return (
    <div className="App">
      
      <h2 className="title">Prove Your Pashto Skills!</h2>

      
      <h3 className="subtitle">Click to Reveal!</h3>
      <Counter indx = {currentCard}></Counter>

      
      <div className="scores">
        <h3 className="score"> Score: {correct}</h3>
        <h3 className="streak"> Streak: {streak}</h3>
      </div>
      
      

      <div className="main">
        <button className="prev" onClick={prevCard}>&#x3C;</button>
        <Card question= {flashcards[currentCard].question} answer={flashcards[currentCard].answer}></Card>
       
        <button className="next" onClick={nextCard}>&#62;</button>
        
      </div>

      <div className="subs">
        <input className='answer' value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder='Enter your answer'/>
        <button className="submit" onClick={checkAnswer} title="Submit Answer">Submit</button>
      </div>

    </div>
  )
}

export default App
