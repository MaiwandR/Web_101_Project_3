import React from 'react';


const Counter = (props) => {

    return(

        <>
        
        <h2 className="counter">{props.indx + 1 + "/6"}</h2>
        
        </>
    )
}

export default Counter;